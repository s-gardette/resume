# My resume

My resume
Revolver Ocelot
Revolver Ocelot

## TODO

PWA : https://vite-pwa-org.netlify.app/guide/pwa-minimal-requirements.html
I18N
