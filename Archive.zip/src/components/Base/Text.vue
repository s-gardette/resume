<script setup></script>

<template>
    <p class="">
        <slot />
    </p>
</template>
