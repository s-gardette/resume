<template>
    <p class="text-justify">
        <slot />
    </p>
</template>
